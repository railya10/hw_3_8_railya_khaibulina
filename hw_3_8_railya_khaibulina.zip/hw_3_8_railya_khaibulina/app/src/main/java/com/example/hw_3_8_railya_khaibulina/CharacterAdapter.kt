package com.example.hw_3_8_railya_khaibulina

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.hw_3_8_railya_khaibulina.databinding.ItemCharacterBinding

class CharacterAdapter(private val data: ArrayList<Character>) :
    RecyclerView.Adapter<CharacterAdapter.CharacterViewHolder>() {

    private lateinit var mListener : OnItemClickListener

    interface OnItemClickListener {
        fun onClickListener(character: Character)
    }

    fun setOnClickListener(listener:OnItemClickListener){
        mListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CharacterViewHolder {

           val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_character, parent, false)
        return CharacterViewHolder(itemView, mListener)
    }

    override fun onBindViewHolder(holder: CharacterViewHolder, position: Int) {
        holder.bind(data[position],mListener)
    }

    override fun getItemCount(): Int = data.size

    inner class CharacterViewHolder(private var binding: ItemCharacterBinding, listener : OnItemClickListener)
        : RecyclerView.ViewHolder(binding.root) {
        fun bind(character: Character, listener : OnItemClickListener) {
            binding.apply {
                image.glide(character.image)
                name.text = character.name
                status.text = character.status
                itemView.setOnClickListener{
                    listener.onClickListener(character)
                }
            }

        }

    }
}