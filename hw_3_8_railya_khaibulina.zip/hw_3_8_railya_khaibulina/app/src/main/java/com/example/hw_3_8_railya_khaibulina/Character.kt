package com.example.hw_3_8_railya_khaibulina

data class Character(
    var status: String,
    var name: String,
    var image: String
)
